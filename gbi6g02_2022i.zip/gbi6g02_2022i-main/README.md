# BIOINFORMÁTICA 2022I
Borre esta línea
Inserte un logo 
## DATOS PERSONALES


## DETALLES DEL EQUIPO
Inserte un video de Youtube (sobre cómo ver las propiedades del computador )

## DETALLES DE PROGRAMAS 


