# BIOINFORMÁTICA (GBI6-G02)
## Examen Parcial 1
Esta evaluación corresponde a los temas de: 
- Unix
- Control de la Versión con GitBash
La evaluación tendrá los siguientes componentes: 
- **40%** Escritura de los comandos en la Hoja de Examen
- **40%** Escritura de los comandos y generación de los scripts para resolución.
- **20%** Control de la versión que incluye clonar el repositorio, indicar los commits y generar un Readme.
